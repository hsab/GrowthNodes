addonsDirectory = "C:\\Users\\Hirad\\AppData\\Roaming\\Blender Foundation\\Blender\\2.79\\scripts\\addons\\UMOG\\test"
skipFiles = ['config.py', 'config.default.py', 'compilation_info.json', 'setup.py', 'umog.zip']
skipFolders = {".git", ".idea", "__pycache__", "build", "playground"}